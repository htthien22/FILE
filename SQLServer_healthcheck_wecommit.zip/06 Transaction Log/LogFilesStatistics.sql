-- Transact-SQL script to show log file statistics for all databases as an overview.

/*
This Transact-SQL script uses the DMV sys.dm_os_performance_counters to list log file information
- allocated size in MB
- used size in MB
- free size in MB
- percent of size used
- count of VLF the log have been grow, shrink and truncated since last service start
for all databases, similar to the DBCC SqlPerf(LogSpace) command.
You could change the sort order e.g. to "PVT.[Percent Log Used] DESC" to get the database with to lowest free space in log file on top.

Works with SQL Server 2005 and higher versions in all editions.
Requires VIEW SERVER STATE permissions.
*/

-- Log file statistics for all databases
SELECT PVT.DatabaseName
      ,CONVERT(numeric(38, 1), PVT.[Log File(s) Size (KB)] / 1024.0) AS LogFileSizeMB
      ,CONVERT(numeric(38, 1), PVT.[Log File(s) Used Size (KB)] / 1024.0) AS LogFileUsedMB
      ,CONVERT(numeric(38, 1), (PVT.[Log File(s) Size (KB)]
                                - PVT.[Log File(s) Used Size (KB)]) / 1024.0) AS LogFileFreeMB
      ,PVT.[Percent Log Used] AS PercLogUsed
      ,PVT.[Log Growths] AS LogGrowths
      ,PVT.[Log Shrinks] AS LogShrinks
      ,PVT.[Log Truncations] AS LogTrunc
FROM
    (SELECT RTRIM(SUB.counter_name) AS CounterName
           ,RTRIM(SUB.instance_name) AS DatabaseName
           ,SUB.cntr_value AS CounterValue
     FROM [master].[sys].[dm_os_performance_counters] AS SUB
     WHERE SUB.[object_name] LIKE 'MSSQL$%:Databases%'       -- To be independed of instance name.
           AND SUB.counter_name IN ('Log File(s) Size (KB)'
                                   ,'Log File(s) Used Size (KB)'
                                   ,'Percent Log Used'
                                   ,'Log Growths'
                                   ,'Log Shrinks'
                                   ,'Log Truncations')
    ) AS OPC
PIVOT
    (SUM(OPC.CounterValue)
     FOR OPC.CounterName IN ([Log File(s) Size (KB)]
                            ,[Log File(s) Used Size (KB)]
                            ,[Percent Log Used]
                            ,[Log Growths]
                            ,[Log Shrinks]
                            ,[Log Truncations])
    ) AS PVT
ORDER BY PVT.DatabaseName;