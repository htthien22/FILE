	--Check the path of all user databases 
	SELECT sdb.name,smf.name AS FileName,smf.physical_name
	FROM sys.databases sdb
	JOIN sys.master_files smf
	ON sdb.database_id = smf.database_id
	WHERE sdb.name NOT IN ('master','tempdb','model','msdb')