DECLARE @temp INT;  
SELECT  @temp = 1  
FROM    sys.dm_os_ring_buffers AS dorb  
        CROSS JOIN sys.dm_os_sys_info AS dosi  
WHERE   dorb.ring_buffer_type = 'RING_BUFFER_OOM'  
        AND DATEADD(ss, (-1 * ((dosi.cpu_ticks / CONVERT (FLOAT, (dosi.cpu_ticks/ dosi.ms_ticks)))- dorb.timestamp) / 1000), GETDATE()) > DATEADD(mi,-5, GETDATE());  
SELECT ISNULL(@temp, 0);