--The sample scripts are not supported under any Microsoft standard support 
-- program or service. The sample scripts are provided AS IS without warranty  
-- of any kind. Microsoft further disclaims all implied warranties including,  
-- without limitation, any implied warranties of merchantability or of fitness for 
-- a particular purpose. The entire risk arising out of the use or performance of  
-- the sample scripts and documentation remains with you. In no event shall 
-- Microsoft, its authors, or anyone else involved in the creation, production, or 
-- delivery of the scripts be liable for any damages whatsoever (including, 
-- without limitation, damages for loss of business profits, business interruption, 
-- loss of business information, or other pecuniary loss) arising out of the use 
-- of or inability to use the sample scripts or documentation, even if Microsoft 
-- has been advised of the possibility of such damages 

-- System memory usage
SELECT  total_physical_memory_kb/1024 AS total_physical_memory_mb,
        available_physical_memory_kb/1024 AS available_physical_memory_mb,
        total_page_file_kb / 1024 AS total_page_file_mb,
        available_page_file_kb/1024 AS available_page_file_mb,
        system_memory_state_desc
FROM    sys.dm_os_sys_memory

-- Memory usage by the SQL Server process
SELECT  physical_memory_in_use_kb/1024 AS physical_memory_in_use_mb,
        virtual_address_space_committed_kb/1024 AS virtual_address_space_committed_mb,
        virtual_address_space_available_kb/1024 AS virtual_address_space_available_mb,
        page_fault_count,
        process_physical_memory_low,
        process_virtual_memory_low
FROM    sys.dm_os_process_memory

-- Get total buffer usage by database
SELECT  DB_NAME(database_id) AS [Database Name],
        COUNT(*) * 8 / 1024.0 AS [Cached Size(MB)]
FROM    sys.dm_os_buffer_descriptors
WHERE   database_id > 4 -- exclude system databases
        AND database_id <> 32767 -- exclude ResourceDB
GROUP BY DB_NAME(database_id)
ORDER BY [Cached Size(MB)] DESC ;

--The count of pages loaded for each object in the current database
SELECT COUNT(*)AS cached_pages_count 
    ,name ,index_id 
FROM sys.dm_os_buffer_descriptors AS bd 
    INNER JOIN 
    (
        SELECT object_name(object_id) AS name 
            ,index_id ,allocation_unit_id
        FROM sys.allocation_units AS au
            INNER JOIN sys.partitions AS p 
                ON au.container_id = p.hobt_id 
                    AND (au.type = 1 OR au.type = 3)
        UNION ALL
        SELECT object_name(object_id) AS name   
            ,index_id, allocation_unit_id
        FROM sys.allocation_units AS au
            INNER JOIN sys.partitions AS p 
                ON au.container_id = p.partition_id 
                AND au.type = 2
    ) AS obj 
        ON bd.allocation_unit_id = obj.allocation_unit_id
WHERE database_id = DB_ID()
GROUP BY name, index_id 
ORDER BY cached_pages_count DESC;