USE Master
GO
EXEC sp_who2
GO