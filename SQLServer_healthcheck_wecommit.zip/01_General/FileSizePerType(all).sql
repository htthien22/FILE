-- File sizes per type for all databases.

-- List for all databases the total size of the files per type.

/*
To get an overview creates this statement a pivot table with all database and the total size of the files aggregated by the file type Row, Log, Filestream and Fulltext (for SQL Server versions before 2008). 
The order clause could be changed e.g. to ORDER BY [ROWS] DESC to sort the list descending by the row size.
The size is measured in mega bytes (MB):

Requieres min VIEW ANY DEFINITION permissions.
Works with MS SQL Server 2005 and higher versions in all Editions.
*/

SELECT DbName
      ,DbState
      ,DbRecovery
      ,[ROWS], [LOG], [FILESTREAM], [FULLTEXT]
FROM (
        SELECT DB.name AS DbName
              ,DB.state_desc AS DbState
              ,DB.recovery_model_desc AS DBRecovery
              ,MF.type_desc AS FileType
              ,CONVERT(int, ROUND(MF.size * 0.0078125, 0)) AS SizeMB
        FROM sys.databases AS DB
             INNER JOIN sys.master_files AS MF
                 ON DB.database_id = MF.database_id
        WHERE HAS_DBACCESS(DB.name) = 1
     ) AS DBS
PIVOT (SUM(SizeMB)
       FOR FileType IN ([ROWS], [LOG], [FILESTREAM], [FULLTEXT]) 
      ) AS PVT
ORDER BY DbName
