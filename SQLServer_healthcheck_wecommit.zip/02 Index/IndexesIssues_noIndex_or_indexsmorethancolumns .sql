----------------------------------------------------------------------------------------------------------------
-- The sample scripts are not supported under any Microsoft standard support 
-- program or service. The sample scripts are provided AS IS without warranty  
-- of any kind. Microsoft further disclaims all implied warranties including,  
-- without limitation, any implied warranties of merchantability or of fitness for 
-- a particular purpose. The entire risk arising out of the use or performance of  
-- the sample scripts and documentation remains with you. In no event shall 
-- Microsoft, its authors, or anyone else involved in the creation, production, or 
-- delivery of the scripts be liable for any damages whatsoever (including, 
-- without limitation, damages for loss of business profits, business interruption, 
-- loss of business information, or other pecuniary loss) arising out of the use 
-- of or inability to use the sample scripts or documentation, even if Microsoft 
-- has been advised of the possibility of such damages 
-----------------------------------------------------------------------------------------------------------------
-- Check the current database for common issues such as:
--	tables with no indexes
--	tables with no clustered index but with non-clustered indexes
--	tables with more indexes than columns

-- tables with no indexes
SELECT s.name AS SchemaName, t.name AS ObjectName
FROM sys.indexes AS si 
INNER JOIN sys.tables AS t 
ON si.[object_id] = t.[object_id]
INNER JOIN sys.schemas AS s 
ON s.[schema_id] = t.[schema_id]
GROUP BY si.[object_id], t.name, s.name
HAVING COUNT(index_id) = 1 AND MAX(index_id) = 0
GO
 
--tables with no clustered index but with non-clustered indexes
SELECT s.name AS SchemaName, t.name AS ObjectName
FROM sys.indexes AS si 
INNER JOIN sys.tables AS t ON si.[object_id] = t.[object_id]
INNER JOIN sys.schemas AS s ON s.[schema_id] = t.[schema_id]
GROUP BY t.name, s.name
HAVING COUNT(index_id) > 1 AND MIN(index_id) = 0
GO

--tables with more indexes than columns
SELECT s.name AS SchemaName, t.name AS ObjectName, COUNT(c.column_id) AS ColumnNumber , 
(SELECT COUNT(si.index_id) 
 FROM sys.tables AS t2 
 INNER JOIN sys.indexes AS si 
 ON si.[object_id] = t2.[object_id]
 WHERE si.index_id > 0 AND si.[object_id] = t.[object_id]
 GROUP BY si.[object_id]) AS IndexNumber
FROM sys.tables AS t 
INNER JOIN sys.columns AS c ON t.[object_id] = c.[object_id] 
INNER JOIN sys.schemas AS s ON s.[schema_id] = t.[schema_id]
GROUP BY s.name, t.name, t.[object_id]
HAVING COUNT(c.column_id) < (SELECT COUNT(si.index_id) 
						 FROM sys.tables AS t2 
						 INNER JOIN sys.indexes AS si 
						 ON si.[object_id] = t2.[object_id]
						 WHERE si.index_id > 0 AND si.[object_id] = t.[object_id]
						 GROUP BY si.[object_id])
GO