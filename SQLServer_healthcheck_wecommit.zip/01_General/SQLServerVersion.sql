DECLARE @SQLVersion  nvarchar(128)
DECLARE @Major int
DECLARE @Path varchar(100);

SET @SQLVersion = CONVERT(nvarchar(128),(SELECT SERVERPROPERTY('ProductVersion')))
SELECT @SQLVersion AS [SQL Server Verion]
SET @Major = CONVERT(int,SUBSTRING(@SQLVersion,0,PATINDEX('%.%',@SQLVersion)))

	--Find the installation path of SQL Server
	IF (@Major=9) 
	BEGIN	
		SET @Path = NULL
		EXEC master..xp_regread 'HKEY_LOCAL_MACHINE', 'SOFTWARE\Microsoft\Microsoft SQL Server\90\Tools\ClientSetup', 'SQLPath', @Path OUTPUT
		SELECT @Path AS [SQL Server 2005 path]
	END
	IF (@Major=10)
	BEGIN	
		SET @Path = NULL
		EXEC master..xp_regread 'HKEY_LOCAL_MACHINE', 'SOFTWARE\Microsoft\Microsoft SQL Server\100\Tools\ClientSetup', 'SQLPath', @Path OUTPUT
		SELECT @Path AS [SQL Server 2008/2008 R2 path]
	END
	IF (@Major=11)
	BEGIN	
		SET @Path = NULL
		EXEC master..xp_regread 'HKEY_LOCAL_MACHINE', 'SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\ClientSetup', 'SQLPath', @Path OUTPUT
		SELECT @Path AS [SQL Server 2012 path]
	END